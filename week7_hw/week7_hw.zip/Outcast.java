/**
 * Created with IntelliJ IDEA.
 * User: Pavel_Tsurko
 * Date: 11/16/13
 * Time: 8:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class Outcast {
    // constructor takes a WordNet object
    public Outcast(WordNet wordnet) {

    }

    // given an array of WordNet nouns, return an outcast
    public String outcast(String[] nouns) {
        return null;
    }

    // for unit testing of this class (such as the one below)
    public static void main(String[] args) {

    }
}
